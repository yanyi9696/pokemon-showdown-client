export * from './locales';
